﻿using System;


namespace Esquizofrenia
{
    internal class Cliente
    {
        
    }
}

