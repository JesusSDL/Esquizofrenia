namespace Esquizofrenia
{
    public partial class FormServer : Form
    {
        public FormServer()
        {
            InitializeComponent();
        }
    }
}