﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esquizofrenia.modelo
{
    internal class Plato
    {
            private string nombre { get; set; }
            private int tamaño { get; set; }
            private float precio { get; set; }

    }
}
