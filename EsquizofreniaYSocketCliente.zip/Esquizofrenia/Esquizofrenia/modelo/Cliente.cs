﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esquizofrenia.modelo
{
    internal class Cliente
    {
        public string nombreApellido;
        public int dni { get; set; }

        public string user { get; set; }
        public string password { get; set; }
        public string correoElectronico { get; set; }
        public int idUser { get; set; }
        public int numTelefono { get; set; }

        public Cuenta cuenta;

        public Mesa mesaAsignada;

        public Cliente(string nombreApellido, int dni, string user, string password, string correoElectronico, int idUser, int numTelefono)
        {
            this.nombreApellido = nombreApellido;
            this.dni = dni;
            this.user = user;
            this.password = password;
            this.correoElectronico = correoElectronico;
            this.idUser = idUser;
            this.numTelefono = numTelefono;
        }

        public Cliente(string nombreApellido, int dni, string correoElectronico, int idUser)
        {
            this.dni = dni;
            this.nombreApellido = nombreApellido;
            this.correoElectronico = correoElectronico;
            this.idUser = idUser;


        }
        public void modificarEstadoMesa()
        {
            mesaAsignada.estado = false;
        }
        public void agregarPedido()
        {
            cuenta.agregarPedido();
        }
    }
}
