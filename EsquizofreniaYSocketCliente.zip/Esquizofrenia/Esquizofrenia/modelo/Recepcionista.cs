﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esquizofrenia.modelo
{
    internal class Recepcionista
    {
        string nombreApellido { get; set; }
        string dni { get; set; }

        string user { get; set; }
        string password { get; set; }

        public void moverMesa(Mesa mesa, int x, int y)
        {
            mesa.x = x;
            mesa.y = y;
        }
    }
}
