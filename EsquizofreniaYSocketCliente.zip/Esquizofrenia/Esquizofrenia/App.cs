using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Esquizofrenia
{
    internal static class App
    {
      
        [STAThread]
        static void Main(string[] args)
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new FormServer());
            conectarServidor();
        }

        public static void conectarServidor()
        {
            Socket socketServer = new Socket(AddressFamily.InterNetwork, 
                SocketType.Stream,ProtocolType.Tcp);
            IPEndPoint direccionServer = new IPEndPoint(IPAddress.Any, 1234);

            String recibir(Socket socketCliente)
            {
                byte[] recBy = new byte[255];
                int enteroRecepcionado = socketCliente.Receive(recBy, 0, recBy.Count(), 0);
                Array.Resize(ref recBy, enteroRecepcionado);
                String texto;
                texto = Encoding.Default.GetString(recBy);
                return texto;
            }

            void enviar(Socket socketCliente, String mensaje)
            {
                String Texto = mensaje;
                byte[] TxtAEnviar;
                TxtAEnviar = Encoding.Default.GetBytes(Texto);
                socketCliente.Send(TxtAEnviar, 0, TxtAEnviar.Count(), 0);

            }


            try
            {
                
            }catch(Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.ToString);
            }
        }
    }
}