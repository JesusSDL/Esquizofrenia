﻿using Esquizofrenia.modelo;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esquizofrenia.Dao
{
    internal class ClienteDAO : Conexion
    {
        public ClienteDAO() {
            MySqlConnection c = conectarse();               
        }


        public void prueba()
        {
            string nombre = "jesusDL";
            int dni = 46647703;
            string correo = "jesusdilorenzo335@gmail.com";
            Cliente cliente = new Cliente(nombre, dni, correo, 2);
            agregarCliente(cliente);

        }
        public void agregarCliente(Cliente cliente)
        {
            MySqlConnection c = null;
            c = conectarse();
            string insert = "INSERT INTO cliente (nombre_apellido, dni, correo, USER_id_user) VALUES (@nomApe, @dni, @correo, @idUser);";

            MySqlCommand command = new MySqlCommand(insert, c);
            command.Parameters.Add(new MySqlParameter("@nombre", cliente.nombreApellido));
            command.Parameters.Add(new MySqlParameter("@dni", cliente.dni));
            command.Parameters.Add(new MySqlParameter("@correo", cliente.correoElectronico));
            command.Parameters.Add(new MySqlParameter("@idUser", cliente.idUser));

            //string insertUser = "INSERT INTO user (user, password) VALUES (@user, @password);";
            //  MySqlCommand comandoUser = new MySqlCommand(insertUser, conectarse());
            //  comandoUser.Parameters.Add(new MySqlParameter("@user", cliente.user));
            //  comandoUser.Parameters.Add(new MySqlParameter("@password", cliente.password));
            // comandoUser.ExecuteNonQuery();
            command.ExecuteNonQuery();
        }
        public bool login(Cliente cli)
        {
            string existeCliente = "SELECT user, password FROM user WHERE user = @user and password = @pwd;";
            MySqlCommand comando = new MySqlCommand(existeCliente, conectarse());
            comando.Parameters.Add(new MySqlParameter("@user", cli.user));
            comando.Parameters.Add(new MySqlParameter("@pwd", cli.password));
            return comando.ExecuteNonQuery() == 1;

        }

    }
}
