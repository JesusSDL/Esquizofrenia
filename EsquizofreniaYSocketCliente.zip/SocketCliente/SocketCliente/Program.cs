using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace SocketCliente
{
    internal static class Program
    {
  
        [STAThread]
        static void Main(string[] args)
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());

            Thread hiloIniciar = new Thread(conectarseAlServer);
            hiloIniciar.Start();    
        }

        public static void conectarseAlServer()
        {
            Socket socketCliente = new Socket(AddressFamily.InterNetwork,
                SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint ipCliente = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1234);

            void enviarTexto(Socket socketServidor, String txt)
            {
                byte[] txtAEnviar;
                txtAEnviar = Encoding.Default.GetBytes(txt);
                socketServidor.Send(txtAEnviar, 0, txtAEnviar.Count(), 0);
            }

            String recibir(Socket socketServidor)
            {
                byte[] recibi2 = new byte[255];
                int enterito = socketServidor.Receive(recibi2, 0, recibi2.Count(), 0);
                String texto = Encoding.Default.GetString(recibi2);
                return texto;
            }

            try
            {
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error" + ex.ToString());
            }


        }
    }
}